package com.game.skills.effects;

/**
 * Enum untuk tipe efek status.
 */
public enum EffectType {
    BUFF, // Efek positif
    DEBUFF // Efek negatif
}
